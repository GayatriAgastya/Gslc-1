<!DOCTYPE html>
<link rel="stylesheet" href="{{ asset('style.css') }}">
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GSLC 1</title>
</head>

<div class = "footer">
    <p> gslc 1 web programming </p>
</div>
</html>
