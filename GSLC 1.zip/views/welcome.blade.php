@extends('header')

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

@section('selamat datang', 'di kelas!')

@section('section')
   @for ($i = 0; $i < 10; $i++)
      @if ($i % 2 == 0)
         <p>web programming LB </p>
      @else
         <p>web programming LA </p>
      @endif
         <p> selamat belajar </p>
   @endfor

   @include('footer')